<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>

<div class="vc_welcome-header vc_welcome-visible-e vc_selected-post-custom-layout-visible-ne">
	<?php esc_html_e( 'This is an empty page', 'js_composer' ); ?>
	<br/>
	<?php esc_html_e( 'Select the layout and start building', 'js_composer' ); ?>
</div>
